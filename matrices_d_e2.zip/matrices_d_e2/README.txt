build (compilation):
g++ matrix.cpp pvl_main.cpp

run:
a.out
